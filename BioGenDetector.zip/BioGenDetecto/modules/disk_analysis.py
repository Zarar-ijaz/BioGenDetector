import os
import re
from rich.console import Console
from rich.table import Table

console = Console()

def analyze_disk(disk_path):
    findings = []
    
    # 1. Prefetch File Analysis
    prefetch_dir = os.path.join(disk_path, "Prefetch")
    if os.path.exists(prefetch_dir):
        for file in os.listdir(prefetch_dir):
            if file.endswith(".pf"):
                if "WMIC.EXE" in file.upper() or "POWERSHELL.EXE" in file.upper():
                    findings.append({
                        "severity": "High",
                        "category": "Disk",
                        "description": f"Suspicious Prefetch file: {file} (WMI/PowerShell activity)"
                    })

    # 2. WMI Registry Analysis
    registry_path = os.path.join(disk_path, "Registry", "SOFTWARE")
    if os.path.exists(registry_path):
        wmi_keys = [
            r"Microsoft\Windows\CurrentVersion\WMI",
            r"Microsoft\WMI\EventLog"
        ]
        for key in wmi_keys:
            if os.path.exists(os.path.join(registry_path, key)):
                findings.append({
                    "severity": "High",
                    "category": "Disk",
                    "description": f"WMI persistence artifact found in registry: {key}"
                })

    # 3. LNK File Analysis (Recent Documents)
    recent_files = os.path.join(disk_path, "Users", "*", "AppData", "Roaming", "Microsoft", "Windows", "Recent")
    for lnk_file in glob.glob(recent_files):
        if "FDA_Compliance_Review" in lnk_file:
            findings.append({
                "severity": "Medium",
                "category": "Disk",
                "description": f"Malicious LNK file detected: {os.path.basename(lnk_file)}"
            })

    return findings
