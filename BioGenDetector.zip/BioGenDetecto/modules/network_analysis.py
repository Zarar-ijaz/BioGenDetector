# modules/network_analysis.py
from scapy.all import rdpcap, DNSQR
import math
import re
from rich.console import Console

console = Console()

def calculate_entropy(s):
    freq = {}
    for char in s:
        freq[char] = freq.get(char, 0) + 1
    entropy = 0.0
    total = len(s)
    for count in freq.values():
        p = count / total
        entropy -= p * math.log2(p)
    return entropy

def analyze_network(pcap_file):
    findings = []
    try:
        console.print(f"[yellow]Analyzing {pcap_file}...[/yellow]")
        packets = rdpcap(pcap_file)
        suspicious_queries = []
        
        for pkt in packets:
            if pkt.haslayer(DNSQR):
                qname = pkt[DNSQR].qname.decode()
                if re.search(r"doh\.example|cloudflare-dns\.com", qname):
                    subdomain = qname.split('.')[0]
                    if len(subdomain) > 6:
                        entropy = calculate_entropy(subdomain)
                        if entropy > 0.85:
                            suspicious_queries.append({
                                "subdomain": subdomain,
                                "entropy": entropy,
                                "timestamp": pkt.time
                            })

        if suspicious_queries:
            findings.append({
                "severity": "High",
                "category": "Network",
                "description": f"DNS-over-HTTPS exfiltration detected: {len(suspicious_queries)} high-entropy queries (Avg entropy: {sum(q['entropy'] for q in suspicious_queries)/len(suspicious_queries):.2f})"
            })
            
    except Exception as e:
        console.print(f"[red]Network analysis failed: {str(e)}[/red]")

    return findings
