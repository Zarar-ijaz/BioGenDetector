import xml.etree.ElementTree as ET
from rich.console import Console

console = Console()

def analyze_logs(log_path):
    findings = []
    
    try:
        # 1. PowerShell Log Cleared Detection
        tree = ET.parse(log_path)
        for event in tree.findall('.//Event'):
            system = event.find('System')
            event_id = system.find('EventID').text
            
            # Event ID 1102: Log cleared
            if event_id == "1102":
                findings.append({
                    "severity": "High",
                    "category": "Logs",
                    "description": "Security logs were cleared (Event ID 1102)"
                })
            
            # Event ID 4104: PowerShell Script Block Logging
            elif event_id == "4104":
                data = event.find('EventData/Data[@Name="ScriptBlockText"]')
                if data is not None and "Invoke-Expression" in data.text:
                    findings.append({
                        "severity": "Critical",
                        "category": "Logs",
                        "description": "Malicious PowerShell command detected (Event ID 4104)"
                    })

        # 2. WMI Event Subscription Detection
        wmi_events = tree.findall('.//Event[EventID=5861]')
        if wmi_events:
            findings.append({
                "severity": "High",
                "category": "Logs",
                "description": f"WMI event subscription created ({len(wmi_events)} events)"
            })

    except Exception as e:
        console.print(f"[red]Log analysis error: {str(e)}[/red]")

    return findings
