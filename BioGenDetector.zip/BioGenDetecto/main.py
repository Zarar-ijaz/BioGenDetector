# main.py
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track
from rich.prompt import Confirm, Prompt
# Add this at the top of the file
from pathlib import Path

def generate_html_report(findings):
    report_dir = Path("reports")
    report_dir.mkdir(exist_ok=True)
    
    report_path = report_dir / "bioforensic_report.html"
    
    # Simple HTML template
    html_content = f"""
    <html>
    <head><title>BioGenDetector Report</title></head>
    <body>
        <h1>Forensic Analysis Report</h1>
        <ul>
            {"".join(f"<li>[{f['severity']}] {f['description']}</li>" for f in findings)}
        </ul>
    </body>
    </html>
    """
    
    with open(report_path, "w") as f:
        f.write(html_content)
    
    return report_path
from modules import (
    memory_analysis,
    disk_analysis,
    network_analysis,
    log_analysis
)
import os

console = Console()

def print_banner():
    console.print(Panel.fit("""
    ██████╗ ██╗ ██████╗  ██████╗ ███████╗███╗   ██╗██████╗ ███████╗████████╗███████╗██████╗ 
    ██╔══██╗██║██╔════╝ ██╔═══██╗██╔════╝████╗  ██║██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔══██╗
    ██████╔╝██║██║  ███╗██║   ██║█████╗  ██╔██╗ ██║██║  ██║█████╗     ██║   █████╗  ██████╔╝
    ██╔══██╗██║██║   ██║██║   ██║██╔══╝  ██║╚██╗██║██║  ██║██╔══╝     ██║   ██╔══╝  ██╔══██╗
    ██████╔╝██║╚██████╔╝╚██████╔╝███████╗██║ ╚████║██████╔╝███████╗   ██║   ███████╗██║  ██║
    ╚═════╝ ╚═╝ ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚═════╝ ╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
    """, style="bold cyan"))
    console.print(Panel.fit("[bold yellow]Advanced Forensic Detection for Fileless Malware & DNS Exfiltration[/bold yellow]", border_style="bright_white"))

def get_file_path(prompt_message, path_type='file'):
    while True:
        path = Prompt.ask(f"[bold][{path_type.upper()}] {prompt_message}[/bold]")
        if not path:
            return None
        if os.path.exists(path):
            return os.path.abspath(path)
        console.print(f"[red]Error: {path_type.capitalize()} path does not exist! Please try again.[/red]")

def main():
    print_banner()
    findings = []
    analysis_modules = []

    console.print("\n[bold white]Please provide analysis artifacts (press Enter to skip):[/bold white]")

    # Memory Analysis
    if Confirm.ask("[cyan]?[/cyan] Do you want to analyze memory artifacts?"):
        mem_path = get_file_path("Path to memory dump file:", 'file')
        if mem_path:
            analysis_modules.append(("Memory", mem_path, memory_analysis.analyze_memory))

    # Disk Analysis
    if Confirm.ask("[cyan]?[/cyan] Do you want to analyze disk artifacts?"):
        disk_path = get_file_path("Path to disk image directory:", 'directory')
        if disk_path:
            analysis_modules.append(("Disk", disk_path, disk_analysis.analyze_disk))

    # Network Analysis
    if Confirm.ask("[cyan]?[/cyan] Do you want to analyze network artifacts?"):
        net_path = get_file_path("Path to network capture file:", 'file')
        if net_path:
            analysis_modules.append(("Network", net_path, network_analysis.analyze_network))

    # Log Analysis
    if Confirm.ask("[cyan]?[/cyan] Do you want to analyze log files?"):
        log_path = get_file_path("Path to Windows event logs:", 'file')
        if log_path:
            analysis_modules.append(("Logs", log_path, log_analysis.analyze_logs))

    if not analysis_modules:
        console.print("\n[red]No analysis artifacts provided. Exiting...[/red]")
        return

    # Run analysis with progress tracking
    console.print("\n[bold green]Starting analysis...[/bold green]")
    for name, path, func in track(analysis_modules, description="Analyzing artifacts..."):
        console.rule(f"[bold bright_white]{name} Analysis[/bold bright_white]")
        try:
            findings += func(path)
        except Exception as e:
            console.print(f"[red]Error in {name} analysis: {str(e)}[/red]")

    # Display results
    console.rule("[bold red]Detection Summary[/bold red]")
    if findings:
        table = Table(show_header=True, header_style="bold magenta", expand=True)
        table.add_column("Severity", width=12, justify="center")
        table.add_column("Category", width=15, style="cyan")
        table.add_column("Finding", style="bright_white")

        for finding in findings:
            severity_style = "red" if finding["severity"] == "High" else "yellow"
            table.add_row(
                f"[{severity_style}]{finding['severity']}[/{severity_style}]",
                f"[bold]{finding['category']}[/bold]",
                finding['description']
            )
        console.print(table)
    else:
        console.print("[green]No suspicious artifacts found![/green]")

    # Generate report
    if findings and Confirm.ask("\n[cyan]?[/cyan] Generate HTML report?"):
        generate_html_report(findings)
        console.print("[green]✓ Report generated: bioforensic_report.html[/green]")

def generate_html_report(findings):
    # Add HTML report generation logic here
    pass

if __name__ == "__main__":
    main()
